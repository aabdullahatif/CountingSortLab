package org.example;

import java.util.ArrayList;
import java.util.Random;

public class Main {

    public static void showArray(int[] a) {
        for (int value : a) {
            System.out.print(value + " ");
        }
        System.out.println();
    }

    /** Implement the counting sort method */
    public static int[] countingsort(int[] in, int k) {
        int[] count = new int[k + 1];
        int[] sorted = new int[in.length];

        /** Counts how many times each element comes in the input array */
        for (int value : in) {
            count[value]++;
        }

        /** Gives the cumulative count and updates the index */
        for (int i = 1; i < count.length; i++) {
            count[i] += count[i - 1];
        }

        /** Place elements in sorted order */
        for (int i = in.length - 1; i >= 0; i--) {
            sorted[count[in[i]] - 1] = in[i];
            count[in[i]]--;
        }

        return sorted;
    }

    /** Main method */
    public static void main(String[] args) {
        int[] array = {4, 2, 2, 8, 3, 3, 1};
        showArray(array);
        int[] sortedArray = countingsort(array, 8);
        System.out.println("Sorted array:");
        showArray(sortedArray);

        Random rand = new Random();
        int[] largeArray = new int[1000];
        for (int i = 0; i < largeArray.length; i++) {
            largeArray[i] = rand.nextInt(500);
        }

        /** Displays the unsorted large array */
        System.out.println("Unsorted large array:");
        showArray(largeArray);

        int[] largeSortedArray = countingsort(largeArray, 499);
        System.out.println("Sorted large array:");
        showArray(largeSortedArray);

        /** Compares the sorting with the ArrayList */
        ArrayList<Integer> arrayList = new ArrayList<>();
        for (int value : largeArray) {
            arrayList.add(value);
        }

        arrayList.sort(Integer::compareTo);

        boolean areEqual = true;
        for (int i = 0; i < largeArray.length; i++) {
            if (largeSortedArray[i] != arrayList.get(i)) {
                areEqual = false;
                break;
            }
        }

        System.out.println("Are the arrays all equal? " + (areEqual ? "Yes" : "No"));
    }
}
